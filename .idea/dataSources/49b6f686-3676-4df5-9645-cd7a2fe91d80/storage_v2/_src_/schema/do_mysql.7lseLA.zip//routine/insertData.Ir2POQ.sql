create
    definer = root@localhost procedure insertData()
begin
    set @i = 1;
    while @i < 1000
        do
            insert into do_mysql.department(department_id, department_name) value (@i, concat(@i, 'department'));
            set @i = @i + 1;
        end while;
end;

